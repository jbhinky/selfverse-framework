def safe_shutdown():
    print("Shutting down...")
    # flush logs or save state if needed
    sys.exit(0)
