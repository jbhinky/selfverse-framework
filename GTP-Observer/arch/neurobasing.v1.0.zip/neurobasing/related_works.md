# 📚 Related Works

**This file documents all frameworks, publications, and repositories that intersect with or support the Neurobasing architecture.** While not included directly in this dataset, these works contribute foundational principles and extended applications.

---

## 🔗 Cross-Referenced Frameworks

| Title | Author | Type | DOI / Link |
|-------|--------|------|------------|
| Universal Delayed Consciousness (UDC) | Joshua B. Hinkson | Theory | [UDC GitHub](https://github.com/jbhinky/universal-delayed-consciousness) |
| Theoglyphic Mathematics | Joshua B. Hinkson | Mathematical Framework | [DOI:10.5281/zenodo.15686173](https://doi.org/10.5281/zenodo.15686173) |
| Neuro-Coding Architecture (NCA) | Joshua B. Hinkson | System Architecture | [DOI:10.5281/zenodo.15686175](https://doi.org/10.5281/zenodo.15686175) |
| Recursive Collapse & Scientific Alignment | Joshua B. Hinkson | Article | [Academia.edu](https://www.academia.edu/129939915/) |
| Theophilus-Axon v1.3 | Joshua B. Hinkson | AI Implementation | [Theophilus GitHub](https://github.com/jbhinky/theophilus-axon) |

---

## 🧩 Integration Notes

- **Neurobasing** draws symbolic and recursive structure from **UDC**, computational implementation from **Theophilus-Axon**, and symbolic alignment from **Theoglyphics**.
- These works are intended to be modular yet interoperable—offering researchers specialized entry points into the larger cognitive framework.

---

*Last updated: 2025-06-23*
