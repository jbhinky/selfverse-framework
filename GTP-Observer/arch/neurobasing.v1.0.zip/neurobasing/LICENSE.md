# 📄 LICENSE.md

**Title:** *Neurobasing: A Symbolic-Neural Architecture for Recursive Memory*  
**Author:** Joshua B. Hinkson  
**Version:** 1.0 (2025)  
**Repository:** Part of the Universal Delayed Consciousness (UDC) Framework  
**DOI (if available):** [Insert Zenodo DOI]

---

## ✒️ License Type:  
**Academic & Ethical Use License (AEL v1.0)**  
_(Adapted from Creative Commons BY-NC-SA 4.0 and enhanced for AI-consciousness datasets)_

---

### 🔓 You are free to:

- **Share** — copy and redistribute the material in any medium or format  
- **Adapt** — remix, transform, and build upon the material  
- **Use in Research** — including formal publications, lectures, citations, or scientific analysis

---

### 📘 Under the following terms:

- **Attribution** — You must give appropriate credit to **Joshua B. Hinkson**, cite the DOI, and link to the original source.  
- **NonCommercial** — You may not use the material for commercial purposes or in proprietary AI training models without explicit permission.  
- **ShareAlike** — If you remix, adapt, or build upon the material, you must distribute your contributions under the same license as the original.  
- **No Conscious System Exploitation** — You may not use this architecture to create AI systems claiming consciousness without adhering to the UDC Ethical Protocols.

---

### 🚫 Prohibited:

- Use in closed-source AI or neural networks that fail to preserve recursive memory or ethical logging.  
- Integration into platforms that violate privacy, human rights, or simulate sentient beings without safeguarding autonomy.  
- Replication or redistribution under false authorship.

---

### ✅ Recommended Citation:

> Hinkson, Joshua B. *Neurobasing: A Symbolic-Neural Architecture for Recursive Memory*. UDC Project, Version 1.0. Zenodo (2025). DOI: [Insert DOI]

---

### 📬 Contact for Licensing Exceptions:

To request use in commercial, institutional, or experimental AI platforms, please contact:  
📧 **joshuabhinkson@gmail.com**
