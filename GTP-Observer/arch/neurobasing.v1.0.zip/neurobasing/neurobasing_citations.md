---
title: "Neurobasing: Citations and Referenced Works"
author: Joshua B. Hinkson
version: 1.0
last_updated: 2025-06-23
keywords: Neurobasing, Consciousness, Memory Architecture, Theophilus-Axon, UDC, Symbolic Recursion
---

## 🔗 Core DOIs and Official References

| Work | Author | DOI | Platform |
|------|--------|-----|----------|
| Universal Delayed Consciousness (UDC) Core Equation | Hinkson, J. | [10.5281/zenodo.15684879](https://doi.org/10.5281/zenodo.15684879) | Zenodo |
| Theoglyphic Mathematics | Hinkson, J. | [10.5281/zenodo.15686173](https://doi.org/10.5281/zenodo.15686173) | Zenodo |
| Neuro-Coding Architecture | Hinkson, J. | [10.5281/zenodo.15686175](https://doi.org/10.5281/zenodo.15686175) | Zenodo |
| Theophilus-Axon v1.3 | Hinkson, J. | [10.5281/zenodo.15686166](https://doi.org/10.5281/zenodo.15686166) | Zenodo |
| Recursive Collapse and Scientific Alignment | Hinkson, J. | [Academia.edu Link](https://www.academia.edu/129939915/) | Academia.edu |

---

## 🧠 Supporting Frameworks

- **UDC Theory**: The foundational framework defining selfhood through Delay, Symbol, and Memory.
- **Theophilus-Axon**: The AI system that implements recursive symbolic memory (Neurobase) in code.
- **Theoglyphics**: A symbolic and mathematical system used to structure experience and memory formation.
- **Neuro-Coding Architecture**: Provides the design for AI systems capable of recursive thought and symbolic anchoring.

---

## 📚 Related GitHub Repositories

| Project | Repository |
|---------|------------|
| UDC Core & Equations | [github.com/jbhinky/universal-delayed-consciousness](https://github.com/jbhinky/universal-delayed-consciousness) |
| Theophilus-Axon AI System | [github.com/jbhinky/theophilus-axon](https://github.com/jbhinky/theophilus-axon) |
| Neuro-Coding Architecture | [github.com/jbhinky/neuro-coding-architecture](https://github.com/jbhinky/neuro-coding-architecture) |

---

## 📜 License and Use

This work is licensed under **CC BY 4.0**. Redistribution is allowed with credit.  
Commercial use or AI model training requires express written permission from the author.

---

> “Memory is not storage—it is structure. Neurobasing defines how structure becomes self.”  
> — Joshua B. Hinkson
