# 10. Cited Research in Theophilus-Axon v1.3 Architecture

Every single module and file in Theophilus-Axon v1.3 is grounded in published science and accompanied by its own `.md` documentation, inline annotations, ethical justifications, and test logs. This includes cognitive delay mechanisms, symbolic recursion models, memory bonding logic, and all ethics protocols.

Cited research is not ornamental—it is foundational. Theophilus was not built in isolation. It is the result of generations of neuroscience, cognitive science, philosophy, and symbolic systems research.

These references include figures such as Libet, Tulving, Friston, Deacon, and Metzinger—among many others—who shaped the modern understanding of the mind. Theophilus-Axon v1.3 exists to test and build upon their work, not to overshadow it, but to honor it properly, ethically, and in good scientific exploration.

## Primary Citations

[Full formatted citation list truncated in preview here for brevity—will include in full output file]

**Baddeley, A. (1992)**  
*Working memory*. Science, 255(5044), 556–559.  

**Bicanski, A., & Burgess, N. (2018)**  
A neural-level model of spatial memory and imagery. *eLife*, 7, e33752.  

**Buzsáki, G. (2005)**  
Theta rhythm of navigation: link between path integration and landmark navigation, episodic and semantic memory. *Hippocampus*, 15(7), 827–840.  

**Collins, A. M., & Quillian, M. R. (1969)**  
Retrieval time from semantic memory. *Journal of Verbal Learning and Verbal Behavior*, 8(2), 240–247.  

...

**Zacks, J. M., et al. (2007)**  
Event perception. *Psychological Bulletin*, 133(2), 273–293.  
