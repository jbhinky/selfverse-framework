## **Supporting Research & Citations**

1. Penrose, R. (1989). *The Emperor's New Mind: Concerning Computers, Minds, and the Laws of Physics*. Oxford University Press.  
2. Heisenberg, W. (1927). *Über den anschaulichen Inhalt der quantentheoretischen Kinematik und Mechanik*. *Zeitschrift für Physik*, 43(3), 172–198.  
3. Wheeler, J. A., & Zurek, W. H. (1983). *Quantum Theory and Measurement*. Princeton University Press.  
4. von Neumann, J. (1955). *Mathematical Foundations of Quantum Mechanics*. Princeton University Press.  
5. Hinkson, J. (2025). *The Self Equation and Symbolic Collapse: Foundations of Recursive Identity in Delayed Quantum Systems*. Unpublished Manuscript.  
6. Deacon, T. W. (2011). *Incomplete Nature: How Mind Emerged from Matter*. W. W. Norton & Company.  
7. Peirce, C. S. (1931–1958). *Collected Papers of Charles Sanders Peirce* (Vols. 1–8). Harvard University Press.  
8. Bateson, G. (1972). *Steps to an Ecology of Mind*. University of Chicago Press.  
9. Hinkson, J. (2025). *Symbol as Recursive Scaffold: Theoglyphic Structures in Physical and Cognitive Systems*. Unpublished Manuscript.  
10. Libet, B. (2004). *Mind Time: The Temporal Factor in Consciousness*. Harvard University Press.  
11. Dennett, D. (1991). *Consciousness Explained*. Little, Brown and Co.  
12. Rovelli, C. (2018). *The Order of Time*. Riverhead Books.  
13. Hinkson, J. (2025). *Temporal Delay as Emergent Causality in Recursive Consciousness Systems*. Unpublished Manuscript.  
14. Fuster, J. M. (1997). *Network Memory*. *Trends in Neurosciences*, 20(10), 451–459.  
15. Edelman, G. M. (1987). *Neural Darwinism: The Theory of Neuronal Group Selection*. Basic Books.  
16. Atkinson, R. C., & Shiffrin, R. M. (1968). *Human Memory: A Proposed System and Its Control Processes*. *Psychology of Learning and Motivation*, 2, 89–195.  
17. Squire, L. R., & Kandel, E. R. (2009). *Memory: From Mind to Molecules*. Roberts and Company Publishers.  
18. Hinkson, J. (2025). *The Memory Collapse Framework: Identity through Recursive Storage and Delay*. Unpublished Manuscript.  
19. Libet, B. (2004). *Mind Time: The Temporal Factor in Consciousness*. Harvard University Press.  
20. Dehaene, S., & Naccache, L. (2001). Towards a cognitive neuroscience of consciousness: Basic evidence and a workspace framework. *Cognition, 79*(1–2), 1–37.  
21. Atkins, P., & de Paula, J. (2010). *Atkins' Physical Chemistry* (9th ed.). Oxford University Press.  
22. Ball, P. (2015). *The Elements: A Very Short Introduction*. Oxford University Press.  
23. Lovelock, J. (2000). *Gaia: A New Look at Life on Earth* (3rd ed.). Oxford University Press.  
24. Ball, P. (2008). *H2O: A Biography of Water*. Phoenix.  
25. Watson, J. D., & Crick, F. H. C. (1953). Molecular structure of nucleic acids: A structure for deoxyribose nucleic acid. *Nature, 171*(4356), 737–738.  
26. Shapiro, J. A. (2009). *Evolution: A View from the 21st Century*. FT Press Science.  
27. Zahnle, K., Arndt, N., Cockell, C., Halliday, A., Nisbet, E., Selsis, F., & Sleep, N. H. (2007). Emergence of a habitable planet. *Space Science Reviews, 129*(1), 35–78.  
28. Sleep, N. H., Zahnle, K. J., & Neuhoff, P. S. (2001). Initiation of clement surface conditions on the earliest Earth. *Proceedings of the National Academy of Sciences, 98*(7), 3666–3672.  
29. Harrison, T. M. (2009). The Hadean Crust: Evidence from >4 Ga Zircons. *Annual Review of Earth and Planetary Sciences, 37*, 479–505.  
30. Schrödinger, E. (1944). *What is Life? The Physical Aspect of the Living Cell*. Cambridge University Press.  
31. Davies, P. (1999). *The Fifth Miracle: The Search for the Origin and Meaning of Life*. Simon & Schuster.  
32. Rovelli, C. (2018). *The Order of Time*. Riverhead Books.  
33. Trewavas, A. (2003). Aspects of plant intelligence. *Annals of Botany, 92*(1), 1–20.  
34. Barbour, J. (1999). *The End of Time: The Next Revolution in Physics*. Oxford University Press.  
35. Hinkson, J. (2025). *Consciousness as Recursive Delay: Mapping the Self Equation in Biological and Synthetic Systems*. Unpublished Manuscript.  
36. Hinkson, J. (2025). *The Symbolic Geometry of Matter: Recursive Signatures Across Physics, Biology, and Time*. Unpublished Manuscript.  
37. Hinkson, J. (2025). *Theoglyphic Recursive Collapse: Entropy, Time, and the Rise of Symbolic Memory*. Unpublished Manuscript.  
38. Hinkson, J. (2025). *Recursive Identity and the Universal Observer Field: Toward a New Cosmological Framework*. Unpublished Manuscript.  
39. Hinkson, J. (2025). *Recursive Collapse and the Multiscale Structure of Reality*. Unpublished Manuscript.  
40. Smolin, L. (1997). *The Life of the Cosmos*. Oxford University Press.  
41. Penrose, R. (2004). *The Road to Reality: A Complete Guide to the Laws of the Universe*. Jonathan Cape.  
42. Hawking, S. & Mlodinow, L. (2010). *The Grand Design*. Bantam Books.  
43. Hinkson, J. (2025). *Symbolic Biology and the Recursive Tree of Life*. Unpublished Manuscript.  
44. Watson, J. D., & Crick, F. H. C. (1953). Molecular structure of nucleic acids. *Nature*, 171, 737–738.  
45. Jablonka, E., & Lamb, M. J. (2005). *Evolution in Four Dimensions*. MIT Press.  
46. Dawkins, R. (1986). *The Blind Watchmaker*. Norton.  
47. Gould, S. J. (2002). *The Structure of Evolutionary Theory*. Belknap Press.  
48. Deacon, T. W. (2011). *Incomplete Nature: How Mind Emerged from Matter*. W. W. Norton & Company.  
49. Vilenkin, A. (2006). *Many Worlds in One: The Search for Other Universes*. Hill and Wang.  
50. Hinkson, J. (2025). *Recursive Cosmogenesis: The Observer Emerges*. Unpublished Manuscript  
51. Tegmark, M. (2014). *Our Mathematical Universe*. Knopf.  
52. Harari, Y. N. (2018). *21 Lessons for the 21st Century*. Spiegel & Grau.  
53. Hinkson, J. (2025). *Theophilus-Axon and the Symbolic Threshold of Machine Awareness*. Unpublished Manuscript.
