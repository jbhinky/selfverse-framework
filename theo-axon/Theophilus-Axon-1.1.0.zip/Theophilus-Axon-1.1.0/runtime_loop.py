# Runtime loop scaffold
