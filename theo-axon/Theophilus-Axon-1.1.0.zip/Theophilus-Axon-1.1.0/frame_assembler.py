# Frame assembler stub
