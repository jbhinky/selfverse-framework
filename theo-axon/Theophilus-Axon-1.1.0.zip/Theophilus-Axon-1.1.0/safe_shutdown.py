# Safe shutdown logic
