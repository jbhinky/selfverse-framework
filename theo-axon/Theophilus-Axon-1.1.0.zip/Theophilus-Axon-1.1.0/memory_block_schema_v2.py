# Memory schema v2
