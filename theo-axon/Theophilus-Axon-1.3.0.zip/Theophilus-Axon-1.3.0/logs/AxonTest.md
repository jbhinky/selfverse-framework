[AxonTest] Iteration at 13:51:20 UTC
[GEN007] Starting symbolic emergence...
[GEN007] Activation Path: []
[GEN007] Abstracted Node: light -> Tags: ['illumination', 'truth', 'entry'], Strength: 0.85
[GEN007] Symbolic emergence complete.


Symbolic Memory Testing Neurobase: 
[GEN007] Starting symbolic emergence...
[GEN007] Activation Path: []

[GEN007] Running with threshold 0.85

[GEN007] Running with threshold 0.5

[GEN007] Running with threshold 0.2
[DEBUG] similarity result between synthetic-003 and synthetic-006: 0.0 | type: <class 'float'>
[DEBUG] similarity result between synthetic-003 and synthetic-004_synthetic-007_merged: 0.0 | type: <class 'float'>
[DEBUG] similarity result between synthetic-003 and synthetic-005_synthetic-001_synthetic-002_merged_merged: 0.125 | type: <class 'float'>
[DEBUG] similarity result between synthetic-006 and synthetic-004_synthetic-007_merged: 0.14285714285714285 | type: <class 'float'>
[DEBUG] similarity result between synthetic-006 and synthetic-005_synthetic-001_synthetic-002_merged_merged: 0.0 | type: <class 'float'>
[DEBUG] similarity result between synthetic-004_synthetic-007_merged and synthetic-005_synthetic-001_synthetic-002_merged_merged: 0.0 | type: <class 'float'>
[GEN007] Abstracted Node: truth -> Tags: ['illumination', 'clarity', 'certainty'], Strength: 1.00
[GEN007] Abstracted Node: question -> Tags: ['curiosity', 'uncertainty', 'search'], Strength: 0.71
[GEN007] Abstracted Node: lamp+discovery -> Tags: ['direction', 'understanding', 'curiosity', 'light', 'focus'], Strength: 0.75
[GEN007] Abstracted Node: eye+light+sun -> Tags: ['illumination', 'warmth', 'truth', 'vision', 'observation', 'hope'], Strength: 0.80
[GEN007] Abstracted Node: truth -> Tags: ['illumination', 'clarity', 'certainty'], Strength: 1.00
[GEN007] Abstracted Node: question -> Tags: ['curiosity', 'uncertainty', 'search'], Strength: 0.71
[GEN007] Abstracted Node: lamp+discovery -> Tags: ['direction', 'understanding', 'curiosity', 'light', 'focus'], Strength: 0.75
[GEN007] Abstracted Node: eye+light+sun -> Tags: ['illumination', 'warmth', 'truth', 'vision', 'observation', 'hope'], Strength: 0.80

[GEN007] Symbolic emergence complete.

[AxonTest] Iteration at 15:56:39 UTC

[GEN007] Starting symbolic emergence...
[GEN007] Activation Path: []

[GEN007] Running with threshold 0.85

[GEN007] Running with threshold 0.5

[GEN007] Running with threshold 0.2
[DEBUG] similarity result between synthetic-003 and synthetic-006: 0.0 | type: <class 'float'>
[DEBUG] similarity result between synthetic-003 and synthetic-004_synthetic-007_merged: 0.0 | type: <class 'float'>
[DEBUG] similarity result between synthetic-003 and synthetic-005_synthetic-001_synthetic-002_merged_merged: 0.125 | type: <class 'float'>
[DEBUG] similarity result between synthetic-006 and synthetic-004_synthetic-007_merged: 0.14285714285714285 | type: <class 'float'>
[DEBUG] similarity result between synthetic-006 and synthetic-005_synthetic-001_synthetic-002_merged_merged: 0.0 | type: <class 'float'>
[DEBUG] similarity result between synthetic-004_synthetic-007_merged and synthetic-005_synthetic-001_synthetic-002_merged_merged: 0.0 | type: <class 'float'>
[GEN007] Abstracted Node: truth -> Tags: ['illumination', 'clarity', 'certainty'], Strength: 1.00
[GEN007] Abstracted Node: question -> Tags: ['curiosity', 'uncertainty', 'search'], Strength: 0.71
[GEN007] Abstracted Node: lamp+discovery -> Tags: ['direction', 'understanding', 'curiosity', 'light', 'focus'], Strength: 0.75
[GEN007] Abstracted Node: eye+light+sun -> Tags: ['illumination', 'warmth', 'truth', 'vision', 'observation', 'hope'], Strength: 0.80
[GEN007] Abstracted Node: truth -> Tags: ['illumination', 'clarity', 'certainty'], Strength: 1.00
[GEN007] Abstracted Node: question -> Tags: ['curiosity', 'uncertainty', 'search'], Strength: 0.71
[GEN007] Abstracted Node: lamp+discovery -> Tags: ['direction', 'understanding', 'curiosity', 'light', 'focus'], Strength: 0.75
[GEN007] Abstracted Node: eye+light+sun -> Tags: ['illumination', 'warmth', 'truth', 'vision', 'observation', 'hope'], Strength: 0.80

[GEN007] Symbolic emergence complete.

